(function () {
  var root = document.documentElement;
  var themeBtn = document.getElementById("theme");
  var burger = document.getElementById("burger");
  var menu = document.getElementById("menu");

  function isDark() {
    var t = root.dataset.theme;
    return t ? t === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
  }
  function syncTheme() {
    themeBtn.setAttribute("aria-label", isDark() ? "Switch to light mode" : "Switch to dark mode");
  }
  themeBtn.addEventListener("click", function () {
    var next = isDark() ? "light" : "dark";
    root.dataset.theme = next;
    try { localStorage.setItem("theme", next); } catch (e) {}
    syncTheme();
  });
  syncTheme();

  burger.addEventListener("click", function () {
    var open = menu.classList.toggle("open");
    burger.setAttribute("aria-expanded", open);
    burger.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  });
  menu.addEventListener("click", function (e) {
    if (e.target.tagName === "A") {
      menu.classList.remove("open");
      burger.setAttribute("aria-expanded", "false");
    }
  });

  // Reveal sections on scroll
  var items = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    items.forEach(function (el) { io.observe(el); });
  } else {
    items.forEach(function (el) { el.classList.add("in"); });
  }

  // Contact form: opens the visitor's email app with the message filled in
  var form = document.getElementById("form");
  var msg = document.getElementById("msg");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (!form.checkValidity()) {
      msg.textContent = "Please fill in your name, a valid email, and a message.";
      form.reportValidity();
      return;
    }
    var d = new FormData(form);
    var body = d.get("message") + "\n\nFrom: " + d.get("name") + " (" + d.get("email") + ")";
    window.location.href = "mailto:najeef1997@gmail.com?subject=" +
      encodeURIComponent("Portfolio enquiry from " + d.get("name")) +
      "&body=" + encodeURIComponent(body);
    msg.textContent = "Your email app should open with the message ready to send.";
  });

  document.getElementById("yr").textContent = new Date().getFullYear();
})();
