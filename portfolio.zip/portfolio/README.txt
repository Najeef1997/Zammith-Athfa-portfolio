Put your CV at assets/Zammith-Athfa-CV.pdf and search for "TODO" in index.html.
